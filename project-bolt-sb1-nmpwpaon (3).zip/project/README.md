# Hotel Booking App - Installation Instructions

## Prerequisites

1. Install Node.js from [nodejs.org](https://nodejs.org/)
2. Install NativeScript CLI globally:
```bash
npm install -g @nativescript/cli
```

## Setup Instructions

1. Create a new directory for your project:
```bash
mkdir hotel-booking-app
cd hotel-booking-app
```

2. Clone or download all project files into this directory

3. Install dependencies:
```bash
npm install
```

4. Open the project in Visual Studio Code:
```bash
code .
```

## Required VS Code Extensions

Install these extensions for the best development experience:

1. NativeScript Extension for Visual Studio Code
2. TypeScript and JavaScript Language Features
3. Tailwind CSS IntelliSense

## Running the Application

- To run in preview mode:
```bash
ns preview
```

- To run on Android:
```bash
ns run android
```

- To run on iOS (macOS only):
```bash
ns run ios
```

## Project Structure

```
app/
├── components/
│   ├── booking/
│   ├── hotel-details/
│   └── hotel-list/
├── models/
├── services/
├── utils/
├── app.css
├── app.ts
└── app-root.xml
```