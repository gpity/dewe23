import { Observable } from '@nativescript/core';
import { Hotel } from '../../models/hotel';
import { HotelService } from '../../services/hotel-service';
import { Frame } from '@nativescript/core';

export class HotelDetailsViewModel extends Observable {
    private _hotel: Hotel;
    private hotelService: HotelService;

    constructor(hotelId: string) {
        super();
        this.hotelService = new HotelService();
        this._hotel = this.hotelService.getHotelById(hotelId);
    }

    get hotel(): Hotel {
        return this._hotel;
    }

    onBookTap() {
        Frame.topmost().navigate({
            moduleName: 'components/booking/booking-page',
            context: { hotelId: this._hotel.id }
        });
    }
}