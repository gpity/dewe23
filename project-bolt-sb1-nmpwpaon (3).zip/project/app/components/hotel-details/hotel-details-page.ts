import { NavigatedData, Page } from '@nativescript/core';
import { HotelDetailsViewModel } from './hotel-details-view-model';

export function onNavigatingTo(args: NavigatedData) {
    const page = <Page>args.object;
    const hotelId = page.navigationContext.hotelId;
    page.bindingContext = new HotelDetailsViewModel(hotelId);
}