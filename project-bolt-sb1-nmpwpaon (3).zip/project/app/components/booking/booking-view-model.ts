import { Observable } from '@nativescript/core';
import { Hotel } from '../../models/hotel';
import { HotelService } from '../../services/hotel-service';
import { BookingService } from '../../services/booking-service';

export class BookingViewModel extends Observable {
    private _hotel: Hotel;
    private _checkInDate: Date = new Date();
    private _checkOutDate: Date = new Date();
    private _roomCount: number = 1;
    private _guestName: string = '';
    
    constructor(hotelId: string) {
        super();
        const hotelService = new HotelService();
        this._hotel = hotelService.getHotelById(hotelId);
        
        // Set default checkout date to tomorrow
        this._checkOutDate.setDate(this._checkOutDate.getDate() + 1);
    }
    
    get checkInDate(): Date {
        return this._checkInDate;
    }
    
    set checkInDate(value: Date) {
        if (this._checkInDate !== value) {
            this._checkInDate = value;
            this.notifyPropertyChange('checkInDate', value);
            this.notifyPropertyChange('totalPrice', this.totalPrice);
        }
    }
    
    get checkOutDate(): Date {
        return this._checkOutDate;
    }
    
    set checkOutDate(value: Date) {
        if (this._checkOutDate !== value) {
            this._checkOutDate = value;
            this.notifyPropertyChange('checkOutDate', value);
            this.notifyPropertyChange('totalPrice', this.totalPrice);
        }
    }
    
    get roomCount(): number {
        return this._roomCount;
    }
    
    set roomCount(value: number) {
        if (this._roomCount !== value) {
            this._roomCount = value;
            this.notifyPropertyChange('roomCount', value);
            this.notifyPropertyChange('totalPrice', this.totalPrice);
        }
    }
    
    get guestName(): string {
        return this._guestName;
    }
    
    set guestName(value: string) {
        if (this._guestName !== value) {
            this._guestName = value;
            this.notifyPropertyChange('guestName', value);
        }
    }
    
    get totalPrice(): number {
        const days = Math.ceil((this._checkOutDate.getTime() - this._checkInDate.getTime()) / (1000 * 60 * 60 * 24));
        return this._hotel.price * days * this._roomCount;
    }
    
    onConfirmBooking() {
        const bookingService = new BookingService();
        bookingService.createBooking({
            hotelId: this._hotel.id,
            checkIn: this._checkInDate,
            checkOut: this._checkOutDate,
            guestName: this._guestName,
            roomCount: this._roomCount
        });
    }
}