import { Observable } from '@nativescript/core';
import { Hotel } from '../../models/hotel';
import { HotelService } from '../../services/hotel-service';
import { navigateToHotelDetails } from '../../utils/navigation-utils';

export class HotelListViewModel extends Observable {
    private _hotels: Hotel[] = [];
    private _searchQuery: string = '';
    private hotelService: HotelService;

    constructor() {
        super();
        this.hotelService = new HotelService();
        this.loadHotels();
    }

    get hotels(): Hotel[] {
        return this._hotels;
    }

    set hotels(value: Hotel[]) {
        if (this._hotels !== value) {
            this._hotels = value;
            this.notifyPropertyChange('hotels', value);
        }
    }

    get searchQuery(): string {
        return this._searchQuery;
    }

    set searchQuery(value: string) {
        if (this._searchQuery !== value) {
            this._searchQuery = value;
            this.notifyPropertyChange('searchQuery', value);
        }
    }

    loadHotels() {
        this.hotels = this.hotelService.getHotels();
    }

    onSearch() {
        if (this.searchQuery.trim()) {
            this.hotels = this.hotelService.searchHotels(this.searchQuery);
        } else {
            this.loadHotels();
        }
    }

    onHotelTap(args: any) {
        const hotel = this.hotels[args.index];
        navigateToHotelDetails(hotel.id);
    }
}