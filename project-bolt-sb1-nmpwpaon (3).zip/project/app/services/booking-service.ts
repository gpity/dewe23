import { Observable } from '@nativescript/core';
import { Reservation } from '../models/hotel';

export class BookingService extends Observable {
    private bookings: Reservation[] = [];

    createBooking(booking: Omit<Reservation, 'id'>): Reservation {
        const newBooking: Reservation = {
            id: Date.now().toString(),
            ...booking
        };
        
        this.bookings.push(newBooking);
        return newBooking;
    }

    getBookingsByHotel(hotelId: string): Reservation[] {
        return this.bookings.filter(booking => booking.hotelId === hotelId);
    }

    getBooking(id: string): Reservation | undefined {
        return this.bookings.find(booking => booking.id === id);
    }
}