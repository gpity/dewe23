import { Observable } from '@nativescript/core';
import { Hotel } from '../models/hotel';

export class HotelService extends Observable {
  private hotels: Hotel[] = [
    {
      id: '1',
      name: 'Grand Hotel',
      address: 'Москва, ул. Тверская, 10',
      rating: 4.5,
      price: 5000,
      available: true,
      imageUrl: 'https://example.com/hotel1.jpg',
      description: 'Роскошный отель в центре города'
    },
    {
      id: '2',
      name: 'Business Plaza',
      address: 'Москва, ул. Арбат, 25',
      rating: 4.0,
      price: 4000,
      available: true,
      imageUrl: 'https://example.com/hotel2.jpg',
      description: 'Современный бизнес-отель'
    }
  ];

  getHotels(): Hotel[] {
    return this.hotels;
  }

  getHotelById(id: string): Hotel | undefined {
    return this.hotels.find(hotel => hotel.id === id);
  }

  searchHotels(query: string): Hotel[] {
    return this.hotels.filter(hotel => 
      hotel.name.toLowerCase().includes(query.toLowerCase()) ||
      hotel.address.toLowerCase().includes(query.toLowerCase())
    );
  }
}