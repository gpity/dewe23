export interface Hotel {
  id: string;
  name: string;
  address: string;
  rating: number;
  price: number;
  available: boolean;
  imageUrl: string;
  description: string;
}

export interface Reservation {
  id: string;
  hotelId: string;
  checkIn: Date;
  checkOut: Date;
  guestName: string;
  roomCount: number;
}