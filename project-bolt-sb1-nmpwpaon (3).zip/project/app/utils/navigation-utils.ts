import { Frame } from '@nativescript/core';

export function navigateToHotelDetails(hotelId: string) {
    Frame.topmost().navigate({
        moduleName: 'components/hotel-details/hotel-details-page',
        context: { hotelId }
    });
}